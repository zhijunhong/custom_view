package fudaojun.com.toggle_iew;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

public class ToggleView extends View {
    public ToggleView(Context context) {
        super(context);
    }

    public ToggleView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public ToggleView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
